//
//  ViewController.m
//  Widget Store
//
//  Created by Developer on 23/12/16.
//  Copyright © 2016 Antique. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    NSString *fullURL = @"http://widgetstore.tk";
    NSURL *url = [NSURL URLWithString:fullURL];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [_webView loadRequest:request];
    
    self.searchBar.hidden = YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)searchOpen:(id)sender {
        self.searchBar.hidden = NO;
    }

@end
