//
//  AboutViewController.m
//  Widget Store
//
//  Created by Developer on 23/12/16.
//  Copyright © 2016 Antique. All rights reserved.
//

#import "AboutViewController.h"

@interface AboutViewController ()

//Avatar Views
@property (weak, nonatomic) IBOutlet UIImageView *dylan;
@property (weak, nonatomic) IBOutlet UIImageView *dubai;
@property (weak, nonatomic) IBOutlet UIImageView *junes;
@property (weak, nonatomic) IBOutlet UIImageView *antique;

//Background Views
@property (weak, nonatomic) IBOutlet UIView *backgroundIcon1;
@property (weak, nonatomic) IBOutlet UIView *backgroundIcon2;
@property (weak, nonatomic) IBOutlet UIView *backgroundIcon3;
@property (weak, nonatomic) IBOutlet UIView *backgroundIcon4;


@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //Dylan
    _dylan.layer.cornerRadius = 8;
    _dylan.clipsToBounds = YES;
    //Border
    _dylan.layer.borderWidth = 4.0f;
    _dylan.layer.borderColor = [UIColor colorWithRed:110.0f/255.0f green:145.0f/255.0f blue:255.0f/255.0f alpha:1].CGColor;
    
    //Junes
    _junes.layer.cornerRadius = 8;
    _junes.clipsToBounds = YES;
    //Border
    _junes.layer.borderWidth = 4.0f;
    _junes.layer.borderColor = [UIColor colorWithRed:110.0f/255.0f green:165.0f/255.0f blue:165.0f/255.0f alpha:1].CGColor;
    
    //Dubai
    _dubai.layer.cornerRadius = 8;
    _dubai.clipsToBounds = YES;
    //Border
    _dubai.layer.borderWidth = 4.0f;
    _dubai.layer.borderColor = [UIColor colorWithRed:182.0f/255.0f green:108.0f/255.0f blue:206.0f/255.0f alpha:1].CGColor;
    
    //Antique
    _antique.layer.cornerRadius = 8;
    _antique.clipsToBounds = YES;
    //Border
    _antique.layer.borderWidth = 4.0f;
    _antique.layer.borderColor = [UIColor colorWithRed:225.0f/255.0f green:118.0f/255.0f blue:121.0f/255.0f alpha:1].CGColor;
    
    ////////////////////////////////
    
    //Set Radius
    _backgroundIcon1.layer.cornerRadius = 5;
    _backgroundIcon2.layer.cornerRadius = 5;
    _backgroundIcon3.layer.cornerRadius = 5;
    _backgroundIcon4.layer.cornerRadius = 5;
    
    //Set Bounds
    _backgroundIcon1.clipsToBounds = YES;
    _backgroundIcon2.clipsToBounds = YES;
    _backgroundIcon3.clipsToBounds = YES;
    _backgroundIcon4.clipsToBounds = YES;
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//Twitter Links
//Dylan
- (IBAction)dylanTwitter:(id)sender {
    NSString *user = @"dylanduff3";
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetbot:"]])
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetbot://user_profile/" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitterrific:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitterrific:///profile?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetings:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetings:///user?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitter:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitter://user?screen_name=" stringByAppendingString:user]]];
    
    else [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"https://mobile.twitter.com/" stringByAppendingString:user]]];
}

//Dubai
- (IBAction)dubaiTwitter:(id)sender {
    NSString *user = @"dubailive1";
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetbot:"]])
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetbot://user_profile/" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitterrific:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitterrific:///profile?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetings:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetings:///user?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitter:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitter://user?screen_name=" stringByAppendingString:user]]];
    
    else [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"https://mobile.twitter.com/" stringByAppendingString:user]]];
}


//Junes
- (IBAction)junesTwitter:(id)sender {
    NSString *user = @"junesiphone";
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetbot:"]])
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetbot://user_profile/" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitterrific:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitterrific:///profile?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetings:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetings:///user?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitter:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitter://user?screen_name=" stringByAppendingString:user]]];
    
    else [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"https://mobile.twitter.com/" stringByAppendingString:user]]];
}


//Antique
- (IBAction)antiqueTwitter:(id)sender {
NSString *user = @"Antique_Dev";
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetbot:"]])
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetbot://user_profile/" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitterrific:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitterrific:///profile?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tweetings:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"tweetings:///user?screen_name=" stringByAppendingString:user]]];
    
    else if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"twitter:"]]) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"twitter://user?screen_name=" stringByAppendingString:user]]];
    
    else [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"https://mobile.twitter.com/" stringByAppendingString:user]]];
}


@end
