//
//  ViewController.h
//  Widget Store
//
//  Created by Developer on 23/12/16.
//  Copyright © 2016 Antique. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *cancelSearch;
@end

