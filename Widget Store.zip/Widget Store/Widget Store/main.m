//
//  main.m
//  Widget Store
//
//  Created by Developer on 23/12/16.
//  Copyright © 2016 Antique. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
