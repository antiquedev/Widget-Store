//
//  AboutViewController.h
//  Widget Store
//
//  Created by Developer on 23/12/16.
//  Copyright © 2016 Antique. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@end
