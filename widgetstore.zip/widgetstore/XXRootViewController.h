@interface XXRootViewController : UIViewController <UIWebViewDelegate>
@end

UIWebView *webView;